# Carry People by the1andonly_carmine partnered with SoloSquadScripts

Instructions on how to use:
Type /carry close to someone then either person can cancel by again doing /carry

Feel free to make improvements with PRs
