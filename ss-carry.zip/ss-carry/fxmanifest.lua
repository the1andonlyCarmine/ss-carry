-- SoloSquadScripts
fx_version 'bodacious'
games { 'gta5' }
lua54 'yes'
author 'the1andonly_carmine'
description 'CarryPeople'
version '1.2.0'

client_script "cl_carry.lua"
server_script "sv_carry.lua"
